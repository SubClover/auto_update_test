import requests
import os

with open("version.txt", "r") as f:
  local_version = f.read().strip()

r = requests.get("https://github.com/SubClover/auto_update_test/raw/refs/heads/main/version.txt")
remote_version = r.text.strip()

if local_version != remote_version:
  print("アップデートがあります。")
  os.system("python update.py")
  exit()
else:
  print("最新です。")
